# SQL_Tools

This is a sample powerbi dashboard to understand performance issues using queries in a SQL Server. 
To use this:
  Deploy SQL scripts on your SQL Server instance to collect sample data using Job Script.sql
  Change the Data Source in the Power BI dashboard to point to dbadmin database and import the tables.
