print  '--Perf_Head_Blocker'
	set nocount on;
	SELECT 
			@@SERVERNAME as InstanceName,db_name() as databasename,
			CONVERT (varchar(30), getdate(), 121) as Collection_Time,
				t1.resource_type AS [lock type], 
				DB_NAME(resource_database_id) AS [database],
				t1.resource_associated_entity_id AS [blk object],
				t1.request_mode AS [lock req],  -- lock requested
				t1.request_session_id AS [waiter sid], 
				t2.wait_duration_ms AS [wait time],       -- spid of waiter 
				(  SELECT substring (REPLACE (REPLACE (SUBSTRING (s1.text , (r1.statement_start_offset/2) + 1 ,
									( (CASE r1.statement_end_offset WHEN -1 THEN DATALENGTH(s1.text) ELSE r1.statement_end_offset
									END - r1.statement_start_offset)/2) + 1) , CHAR(10), ' '), CHAR(13), ' '), 1, 2000) AS statement_text
					FROM sys.dm_exec_requests AS r1 WITH (NOLOCK)
					CROSS APPLY sys.dm_exec_sql_text(r1.[sql_handle]) AS s1
					WHERE r1.session_id = t1.request_session_id
				) AS [waiter_stmt],					-- statement blocked 
				t2.blocking_session_id AS [blocker sid],										-- spid of blocker
				(
					SELECT [text] FROM sys.sysprocesses AS p										-- get sql for blocker
					CROSS APPLY sys.dm_exec_sql_text(p.[sql_handle]) 
					WHERE p.spid = t2.blocking_session_id
				) AS [blocker_full_text]
				,t2.blocking_session_id AS [blocker sid],										-- spid of blocker
				(
					SELECT substring (REPLACE (REPLACE (SUBSTRING (s1.text , (r1.stmt_start/2) + 1 ,
					( (CASE r1.stmt_end WHEN -1 THEN DATALENGTH(s1.text) ELSE r1.stmt_end
					END - r1.stmt_start)/2) + 1) , CHAR(10), ' '), CHAR(13), ' '), 1, 2000) AS blocker_batch 
					FROM sys.sysprocesses AS r1										-- get sql for blocker
					CROSS APPLY sys.dm_exec_sql_text(r1.[sql_handle]) s1 
					WHERE r1.spid = t2.blocking_session_id
				) AS [blocker_batch]
	FROM sys.dm_tran_locks AS t1 WITH (NOLOCK)
	INNER JOIN sys.dm_os_waiting_tasks AS t2 WITH (NOLOCK) ON t1.lock_owner_address = t2.resource_address 
	OPTION (RECOMPILE); 