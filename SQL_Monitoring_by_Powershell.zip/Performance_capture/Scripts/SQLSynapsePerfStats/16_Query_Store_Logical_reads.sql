print '--Query_Store_Logical_reads'
	if(db_name()<>'master')
		begin
			select top 200
					@@SERVERNAME as ServerName,
					db_name() as db_name,
					max(p.query_id) as query_id,
					q.query_hash,
					cast(cast(q.query_hash as bigint) as nvarchar(50)) as query_hash_bigint,
					max(left(qt.query_sql_text, 30000)) as query_sql_text,
					sum(count_executions) as total_executions,
					sum(count_executions * avg_rowcount) as total_row_count,
					round(sum(count_executions * avg_duration) / 1000000, 2) as total_duration_sec,
					round(sum(count_executions * avg_duration) / sum(count_executions) / 1000000, 2) as avg_duration_sec,
					round(max(max_duration) / cast(1000000 as float), 2) as max_duration_sec,
					round(sum(count_executions * avg_cpu_time) / 1000000, 2) as total_cpu_time_sec,
					sum(count_executions * avg_logical_io_reads * 8) as total_logical_io_reads_kb,
					sum(count_executions * avg_logical_io_writes * 8) as total_logical_io_writes_kb,
					sum(count_executions * avg_physical_io_reads * 8) as total_physical_io_reads_kb
			from sys.query_store_runtime_stats as rs
			inner join sys.query_store_plan as p on rs.plan_id = p.plan_id
			inner join sys.query_store_query as q on p.query_id = q.query_id
			inner join sys.query_store_query_text as qt on q.query_text_id = qt.query_text_id
			where ((rs.first_execution_time >= getdate()-7 and rs.first_execution_time <= getdate()) or
					(rs.first_execution_time >= getdate()-7 and rs.first_execution_time <= getdate()))
			group by
			q.query_hash
			order by total_logical_io_reads_kb desc;
		end