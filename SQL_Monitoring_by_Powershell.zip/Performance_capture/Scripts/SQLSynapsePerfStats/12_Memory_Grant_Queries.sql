print '--Memory_Grant_Queries'
	--Active requests with memory grants
		SELECT CONVERT (varchar(30), getdate(), 121) as Collection_Time,
		--Session connection information
			s.host_name, s.program_name, s.login_name, s.client_interface_name, s.is_user_process, s.last_request_start_time, s.last_request_end_time,
		--Session data 
		  s.[session_id], s.open_transaction_count
		--Memory usage
		, r.granted_query_memory, mg.grant_time, mg.requested_memory_kb, mg.granted_memory_kb, mg.required_memory_kb, mg.used_memory_kb, mg.max_used_memory_kb     
		--Query 
		--, query_text = t.text,query_plan_xml = qp.query_plan,
		,substring (REPLACE (REPLACE (SUBSTRING (t.text , (r.statement_start_offset/2) + 1 ,
			( (CASE statement_end_offset WHEN -1 THEN DATALENGTH(t.text) ELSE r.statement_end_offset
			END - r.statement_start_offset)/2) + 1) , CHAR(10), ' '), CHAR(13), ' '), 1, 2000) AS statement_text
		, input_buffer = ib.event_info,  request_row_count = r.row_count, session_row_count = s.row_count
		--Session history and status
		 ,s.reads, s.writes, s.logical_reads, session_status = s.[status], request_status = r.status

		FROM sys.dm_exec_sessions s 
		LEFT OUTER JOIN sys.dm_exec_requests AS r 
			ON r.[session_id] = s.[session_id]
		LEFT OUTER JOIN sys.dm_exec_query_memory_grants AS mg 
			ON mg.[session_id] = s.[session_id]
		OUTER APPLY sys.dm_exec_sql_text (r.[sql_handle]) AS t
		OUTER APPLY sys.dm_exec_input_buffer(s.[session_id], NULL) AS ib 
		--OUTER APPLY sys.dm_exec_query_plan (r.[plan_handle]) AS qp 
		WHERE mg.granted_memory_kb > 0 and s.[session_id] <> @@spid
		ORDER BY mg.granted_memory_kb desc, mg.requested_memory_kb desc
option(recompile);