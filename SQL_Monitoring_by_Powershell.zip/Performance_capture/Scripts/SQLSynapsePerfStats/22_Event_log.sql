--print '--sys.event_log'
	if((serverproperty('edition') = 'SQL Azure' and db_name()='master') AND @@SERVERNAME not like '%.database.windows%')
	begin
			select @@SERVERNAME as ServerName,db_name() as DatabaseName ,* 
			from sys.event_log
	end