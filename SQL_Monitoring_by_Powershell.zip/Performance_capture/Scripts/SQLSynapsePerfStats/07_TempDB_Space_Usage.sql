print '--TempDB_Space_Usage'
	SELECT @@SERVERNAME as ServerName,db_name(database_id) as DatabaseName,CONVERT (varchar(30), getdate(), 121) as Collection_Time,file_name(file_id) as FileName,file_id,
	SUM(allocated_extent_page_count) AS [FilePages], 
	(SUM(allocated_extent_page_count)*1.0/128) AS [File_Space_In_MB], 
	(SUM(unallocated_extent_page_count)) AS [free_free_Pages],
	(SUM(unallocated_extent_page_count)*1.0/128) AS [free_space_in_MB],
	(SUM(version_store_reserved_page_count)) AS [version_store_Pages],
	(SUM(version_store_reserved_page_count)*1.0/128) AS [version_store_space_in_MB],
	(SUM(user_object_reserved_page_count)) AS [user_object_reserved_page_count],
	(SUM(user_object_reserved_page_count)*1.0/128) AS [user_object_reserved_in_MB],
	(SUM(internal_object_reserved_page_count)) AS [internal_object_reserved_page_count],
	(SUM(internal_object_reserved_page_count)*1.0/128) AS [internal_object_reserved_in_MB]
	FROM tempdb.sys.dm_db_file_space_usage
	group by database_id,file_id
      option(recompile);