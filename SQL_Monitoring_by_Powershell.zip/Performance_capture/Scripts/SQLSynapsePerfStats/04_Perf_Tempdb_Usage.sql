print '--Perf_Tempdb_Usage'
		SELECT @@SERVERNAME as InstanceName,CONVERT (varchar(30), getdate(), 121) as Collection_Time,r.*,Sessionspace.*, TASKSPACE.*,d.log_reuse_wait,d.log_reuse_wait_desc,t2.* 
		FROM tempdb.sys.dm_exec_sessions AS t2
		LEFT JOIN tempdb.sys.dm_exec_connections AS t1  ON t1.session_id = t2.session_id         
		OUTER APPLY tempdb.sys.dm_exec_sql_text(t1.most_recent_sql_handle) AS st 
		left JOIN sys.databases d on d.database_id = t2.database_id
		LEFT JOIN (
					SELECT 
					   req.session_id
					   , req.start_time
					   , cpu_time 'cpu_time_ms'
					   , object_name(st.objectid,st.dbid) 'ObjectName' 
					   , substring
						  (REPLACE
							(REPLACE
							  (SUBSTRING
								(ST.text
								, (req.statement_start_offset/2) + 1
								, (
								   (CASE statement_end_offset
									  WHEN -1
									  THEN DATALENGTH(ST.text)  
									  ELSE req.statement_end_offset
									  END
										- req.statement_start_offset)/2) + 1)
						   , CHAR(10), ' '), CHAR(13), ' '), 1, 512)  AS statement_text  
					FROM tempdb.sys.dm_exec_requests AS req  
					   CROSS APPLY tempdb.sys.dm_exec_sql_text(req.sql_handle) as ST 
		) r on r.session_id = t2.session_id
		left JOIN 
		(
			SELECT R2.session_id,
			R1.internal_objects_alloc_page_count   + SUM(R2.internal_objects_alloc_page_count) AS session_internal_objects_alloc_page_count,
			R1.internal_objects_dealloc_page_count  + SUM(R2.internal_objects_dealloc_page_count) AS session_internal_objects_dealloc_page_count
			FROM tempdb.sys.dm_db_session_space_usage AS R1 
			LEFT JOIN tempdb.sys.dm_db_task_space_usage AS R2 ON R1.session_id = R2.session_id
			GROUP BY R2.session_id, R1.internal_objects_alloc_page_count, R1.internal_objects_dealloc_page_count 
		)Sessionspace ON t2.session_id = Sessionspace.session_id
		LEFT JOIN
		(	
			SELECT session_id, 
			SUM(internal_objects_alloc_page_count) AS task_internal_objects_alloc_page_count,
			SUM(internal_objects_dealloc_page_count) AS task_internal_objects_dealloc_page_count 
			FROM tempdb.sys.dm_db_task_space_usage 
			GROUP BY session_id 
		)TASKSPACE ON TASKSPACE.session_id = t2.session_id  
		WHERE   Sessionspace.session_internal_objects_alloc_page_count >0 AND t2.session_id <> @@SPID
            option(recompile);