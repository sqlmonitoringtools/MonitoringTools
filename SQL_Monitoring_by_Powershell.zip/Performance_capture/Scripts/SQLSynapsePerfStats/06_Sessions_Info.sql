print '--Sessions_Info'
			select @@SERVERNAME as InstanceName,CONVERT (varchar(30), getdate(), 121) as Collection_Time,sp.*,ST.text
			from sys.sysprocesses sp
			outer apply sys.dm_exec_sql_text(sp.sql_handle) as ST
			where sp.spid not in (select session_id from sys.dm_exec_requests)
			and sp.status <> 'sleeping'
                  option(recompile);