print '--SQLServerProperties'
	Declare @AuditLevel int,@AuditLevelDesc varchar(50) 
	exec master..xp_instance_regread @rootkey='HKEY_LOCAL_MACHINE', @key='SOFTWARE\Microsoft\MSSQLServer\MSSQLServer', @value_name='AuditLevel', @value=@AuditLevel output
	SET @AuditLevelDesc=CASE @AuditLevel WHEN 0 THEN 'None' WHEN 1 THEN 'Successful Logins Only' WHEN 2 THEN 'Failed Logins Only' WHEN 3 THEN 'Both Failed and Successful Logins' END
	SELECT CONVERT (varchar(30), getdate(), 121) as Collection_Time,@@SERVERNAME InstanceName, @@VERSION InstanceVersion,SERVERPROPERTY('ProductVersion') AS [ProductVersion],SERVERPROPERTY('ProductLevel') AS [ProductLevel],SERVERPROPERTY('Edition') AS [Edition],SERVERPROPERTY('BuildClrVersion') AS [ClrVersion],
	SERVERPROPERTY('Collation') AS [Collation],CASE SERVERPROPERTY('IsIntegratedSecurityOnly') WHEN 1 THEN 'Windows' ELSE 'Mixed' END [AuthenticationMode],SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS [SqlHost],COALESCE(SERVERPROPERTY('InstanceName'), 'MSSQLSERVER') AS [InstanceName],
	SERVERPROPERTY('IsClustered') AS [IsClustered],SERVERPROPERTY('IsFullTextInstalled') AS [IsFullTextInstalled],SERVERPROPERTY('IsSingleUser') AS [IsSingleUser],@AuditLevelDesc LoginAuditing,SERVERPROPERTY('ResourceLastUpdateDateTime') AS [LastUpdateDateTime],SERVERPROPERTY('ComparisonStyle') AS [ComparisonStyle],
	SERVERPROPERTY('LCID') AS [LCID],SERVERPROPERTY('SqlCharSet') AS [SqlCharSet],SERVERPROPERTY('SqlCharSetName') AS [SqlCharSetName], SERVERPROPERTY('SqlSortOrder') AS [SqlSortOrder]
