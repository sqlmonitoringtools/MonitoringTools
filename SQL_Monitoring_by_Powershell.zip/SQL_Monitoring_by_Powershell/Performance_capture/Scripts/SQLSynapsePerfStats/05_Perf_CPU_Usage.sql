print  '--Perf_CPU_Usage'
		
		DECLARE @ts_now BIGINT
		SELECT @ts_now = cpu_ticks / (cpu_ticks/ms_ticks) from sys.dm_os_sys_info;
		SELECT  @@SERVERNAME as InstanceName,db_name() as DatabaseName,
				CAST(CONVERT (varchar(30), getdate(), 121)AS DATETIME) as Collection_Time,
				CAST(DATEADD(ms, -1 * (@ts_now - [timestamp]), GETDATE()) AS DATETIME)  AS EventTime,
				CPUUsage_SQL,
				100 - SystemIdle - CPUUsage_SQL  AS CPUUsage_Other,
				100 - SystemIdle				 AS	CPUUsage_Total
		FROM (SELECT record.value('(./Record/@id)[1]', 'int') AS Record_ID,
				record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int')           AS SystemIdle,
				record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int')   AS CPUUsage_SQL,
				timestamp AS timestamp
			FROM (SELECT timestamp, CONVERT(XML, record) AS record
				FROM sys.dm_os_ring_buffers WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR' AND record LIKE '%<SystemHealth>%'
				) AS x
			) AS y ORDER BY Record_ID DESC
                 option(recompile);