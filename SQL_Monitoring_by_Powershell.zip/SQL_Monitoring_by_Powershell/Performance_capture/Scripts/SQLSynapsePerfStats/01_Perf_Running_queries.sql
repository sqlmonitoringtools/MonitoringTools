print '--Perf_Running_queries'
			set nocount on;
			SELECT
						@@SERVERNAME InstanceName, 
						CONVERT (varchar(30), getdate(), 121) as Collection_Time,
						db_name(req.database_id) as Database_Name,
						object_name(st.objectid,st.dbid) 'ObjectName' ,
						substring (REPLACE (REPLACE (SUBSTRING (ST.text , (req.statement_start_offset/2) + 1 ,
						( (CASE statement_end_offset WHEN -1 THEN DATALENGTH(ST.text) ELSE req.statement_end_offset
						END - req.statement_start_offset)/2) + 1) , CHAR(10), ' '), CHAR(13), ' '), 1, 2000) AS statement_text,
						s.client_interface_name,s.host_name,s.program_name,s.login_name,s.login_time,s.last_request_start_time,s.last_request_end_time,s.logical_reads,s.writes,s.open_transaction_count,
						cs.auth_scheme,cs.client_net_address,cs.client_tcp_port,
						req.*						
			FROM sys.dm_exec_requests AS req
			left join sys.dm_exec_sessions s on s.session_id = req.session_id
			left join sys.dm_exec_connections cs on cs.session_id = req.session_id
			outer APPLY sys.dm_exec_sql_text(req.sql_handle) as ST
			WHERE req.session_id >50
			and req.status not in ('background','sleeping')
			 and req.session_id <> @@SPID
			ORDER BY cpu_time desc
			option(recompile)