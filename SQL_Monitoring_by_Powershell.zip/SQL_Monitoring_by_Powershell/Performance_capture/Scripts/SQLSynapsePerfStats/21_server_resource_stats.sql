if((serverproperty('edition') = 'SQL Azure'   and db_name()='master') AND @@SERVERNAME like '%.database.windows%')
begin
	DECLARE @s datetime;  
	DECLARE @e datetime;  
	SET @s= DateAdd(d,-7,GetUTCDate());  
	SET @e= GETUTCDATE();  
	SELECT * 
	FROM sys.server_resource_stats   
	WHERE start_time BETWEEN @s AND @e;
end