--print '--Server_Stats'
	if((serverproperty('edition') = 'SQL Azure' and db_name()='master') AND @@SERVERNAME not like '%.database.windows%')
	begin
		select @@SERVERNAME as ServerName,db_name() as DatabaseName ,* 
		from sys.resource_stats 
		where start_time between getdate()-7 and getdate() 
		order by database_name,start_time desc
	end