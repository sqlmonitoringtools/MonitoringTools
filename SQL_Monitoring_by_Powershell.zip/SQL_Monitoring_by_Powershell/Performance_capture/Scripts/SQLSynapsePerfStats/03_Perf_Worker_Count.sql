print '--Perf_Worker_Count'
		set nocount on;
		SELECT      @@SERVERNAME as InstanceName, 
				db_name() as databasename, 
				CONVERT (varchar(30), getdate(), 121) as Collection_Time, 
					sum(current_tasks_count) current_tasks_count,
				sum(current_workers_count) current_workers_count,
				sum(active_workers_count) active_workers_count,
				sum(work_queue_count) work_queue_count
		FROM sys.dm_os_schedulers
		WHERE STATUS = 'Visible Online'
		option(recompile);