print '--Repl_Link_Status'
	--15 Repl_Link_Status
	if(serverproperty('edition') = 'SQL Azure' and ((db_name()='master' and @@SERVERNAME like '%.database.windows%') or (db_name()<>'master' and @@SERVERNAME not like '%.database.windows%')))
	begin
		select @@SERVERNAME as ServerName,   
			 link_guid  
		   , partner_server  
		   , last_replication  
		   , replication_lag_sec   
		FROM sys.dm_geo_replication_link_status;  
	end