--print '--Server_Stats'
if((serverproperty('edition') = 'SQL Azure' and db_name()<>'master'))
begin
	select @@SERVERNAME as ServerName,db_name() as DatabaseName ,* 
	From sys.dm_db_resource_stats   
	where end_time between getdate()-7 and getdate() 
	order by end_time desc
end 