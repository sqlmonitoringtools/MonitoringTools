print '--ElasticPool_Stats'
	if((serverproperty('edition') = 'SQL Azure' and db_name()='master') and @@SERVERNAME not like '%.database.windows%')
	begin
		select @@SERVERNAME as ServerName,db_name() as DatabaseName ,* 
		from sys.elastic_pool_resource_stats where start_time between getdate()-2 and getdate()
	end