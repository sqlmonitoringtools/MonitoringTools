print '--Performance_counters'
	SELECT  @@SERVERNAME as InstanceName,db_name() as DatabaseName,CONVERT (varchar(30), getdate(), 121) as Collection_Time,* from sys.dm_os_performance_counters