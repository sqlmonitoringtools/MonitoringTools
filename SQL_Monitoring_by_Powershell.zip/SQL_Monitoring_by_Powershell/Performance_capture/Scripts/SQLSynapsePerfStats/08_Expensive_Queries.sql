print '--Expensive_Queries'
			SELECT  TOP 200 
				@@SERVERNAME as InstanceName,db_name() as DatabaseName,CONVERT (varchar(30), getdate(), 121) as Collection_Time,
				CONVERT( varchar(10), qs.total_elapsed_time / qs.execution_count / 1000000 / 60 ) + 'm '
				+ CONVERT( varchar(10), ( qs.total_elapsed_time / qs.execution_count / 1000000 ) % 60 ) + 's' as Execution_Duration,
				DatabaseName = DB_NAME(qt.dbid),
				ObjectName = OBJECT_NAME(qt.objectid),
				Query = SUBSTRING(qt.text, qs.statement_start_offset / 2,
								  ( CASE WHEN qs.statement_end_offset = -1 THEN LEN(CONVERT(NVARCHAR(MAX), qt.text)) * 2
										 ELSE qs.statement_end_offset
									END - qs.statement_start_offset ) ),
				Executions = qs.execution_count,
				PlanNumber = qs.plan_generation_num,
				PlanCompiledOn = qs.creation_time,
				LastExecutedOn = qs.last_execution_time,		
				TotalCPUTimeInSeconds = qs.total_worker_time / 1000000.0,
				AverageCPUTimeInSeconds = qs.total_worker_time / qs.execution_count / 1000000.0,
				LastCPUTimeInSeconds = qs.last_worker_time / 1000000.0,
				MinCPUTimeInSeconds = qs.min_worker_time / 1000000.0,
				MaxCPUTimeInSeconds = qs.max_worker_time / 1000000.0,		
				TotalExecutionTimeInSeconds = qs.total_elapsed_time / 1000000.0,
				AverageExecutionTimeInSeconds = qs.total_elapsed_time / qs.execution_count / 1000000.0,
				LastExecutionTimeInSeconds = qs.last_elapsed_time / 1000000.0,
				MinExecutionTimeInSeconds = qs.min_elapsed_time / 1000000.0,
				MaxExecutionTimeInSeconds = qs.max_elapsed_time / 1000000.0,
				TotalPhysicalReads = qs.total_physical_reads,
				AveragePhysicalReads = qs.total_physical_reads / qs.execution_count,
				LastPhysicalReads = qs.last_physical_reads,
				MinPhysicalReads = qs.min_physical_reads,
				MaxPhysicalReads = qs.max_physical_reads,
				TotalLogicalReads = qs.total_logical_reads,
				AverageLogicalReads = qs.total_logical_reads / qs.execution_count,
				LastLogicalReads = qs.last_logical_reads,
				MinLogicalReads = qs.min_logical_reads,
				MaxLogicalReads = qs.max_logical_reads,
				TotalLogicalWrites = qs.total_logical_writes,
				AverageLogicalWrites = qs.total_logical_writes / qs.execution_count,
				LastLogicalWrites = qs.last_logical_writes,
				MinLogicalWrites = qs.min_logical_writes,
				MaxLogicalWrites = qs.max_logical_Writes,
				ReferenceCount = cp.refcounts,
				UseCount = cp.usecounts
				--FullExecutionPlan = CONVERT( xml, qp.query_plan ),
				--QueryExecutionPlan = CONVERT( xml, qpt.query_plan )
	FROM    sys.dm_exec_query_stats AS qs
			LEFT JOIN sys.dm_exec_cached_plans cp ON qs.plan_handle = cp.plan_handle 
			OUTER APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
			--OUTER APPLY sys.dm_exec_query_plan(qs.plan_handle) qp
			--OUTER APPLY sys.dm_exec_text_query_plan(qs.plan_handle,qs.statement_start_offset,qs.statement_end_offset) qpt
	 --WHERE   qt.dbid = DB_ID() -- Filter by current database
	--		AND qs.total_elapsed_time / qs.execution_count / 1000000.0 > 0.5
	where last_execution_time >= dateadd(MINUTE,-300,getdate())
	--and ( qs.total_elapsed_time / qs.execution_count / 1000000 ) % 60 >=20
	 ORDER BY Execution_Duration DESC
        option(recompile);