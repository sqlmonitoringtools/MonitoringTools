﻿cls
<#
    How to run :

    Run_SQL_Perf_Collection -PerCollectionTime_In_Min 1 -txtORcsv 0 -samplingPeriod_In_Sec 5 -ApplicationIntentReadOnly 0
#>
 $culture = [System.Globalization.CultureInfo]::GetCultureInfo('en-US')
    [System.Threading.Thread]::CurrentThread.CurrentUICulture = $culture
    [System.Threading.Thread]::CurrentThread.CurrentCulture = $culture

$path=(Get-Location -PSProvider FileSystem).Path 

function GetSQLDataSet($sqlstring,$TSQL)
{   
    $SqlConnection = New-Object System.Data.SqlClient.SqlConnection($sqlstring)   
    $SqlCmd = New-Object System.Data.SqlClient.SqlCommand($TSQL,$SqlConnection)
    $SqlCmd.CommandTimeout = 30;
    $err=@()
    
    try
    {
        $SqlCmd.Connection.open()  
        
    }
    catch
    {
       $TempMess = "  $SQLInst - Failed with errors.... $($_.Exception.Message)"
       Write-Host "      ■ [ERROR] " -ForegroundColor Red -NoNewline
       Write-Host $TempMess 
    }
    finally
    { 
       $SqlConnection.close()
    }
    
    if ($err.count -gt 0)
    {
        "exiting"    
        return @()
    }
    else
    {
        try
        {
            $SQLAdapter = New-Object System.Data.sqlclient.sqlDataAdapter $SqlCmd
            $Dataset = New-Object System.Data.DataSet
            $SQLAdapter.Fill($Dataset)
            $err.clear()
        }
        catch
        {
            $TempMess = " $SQLInst on $SqlCmd - Failed with errors.... $($_.Exception.Message)"
            Write-Host "■ [ERROR] " -ForegroundColor Red -NoNewline
            Write-Host $TempMess 
        }
        finally
        { 
            $SqlConnection.close()
        }
        
        if ($err.count -gt 0)
        {
            return @()
        }
        return [array]$dataSet.Tables
    } 
}

Function Run_SQL_Perf_Collection 
{[Cmdletbinding()]
    Param(
            [Parameter(Mandatory=$true,Position=0,HelpMessage="Please specify Perf Collection Time")] [string]$PerCollectionTime_In_Min,
            [Parameter(Mandatory=$false,Position=1,HelpMessage="Please specify output file type (0 or 1)")] [string]$txtORcsv,
            [Parameter(Mandatory=$true,Position=2,HelpMessage="Please specify sampling period")] [string]$samplingPeriod_In_Sec,
            [Parameter(Mandatory=$false,Position=3,HelpMessage="Please specify Read Only Paramter (0 or 1)")] [string]$ApplicationIntentReadOnly
        )  

    $SQLUserPwd="";
    $TotalErrors = 0;
   
    if($ApplicationIntentReadOnly -eq "" -or $ApplicationIntentReadOnly -eq "0")
    {
        $ApplicationIntentReadOnly = 0
    }
    else
    {
        $ApplicationIntentReadOnly = 1
        $stringparam=';ApplicationIntent=ReadOnly;'
    }

    if($samplingPeriod_In_Sec -eq "")
    {
        $samplingPeriod_In_Sec = 5
    } 

   if($txtORcsv -eq "" -or $txtORcsv -eq "0")
   {
        $FileFormat = ".txt";
   }
   else
   {
        $FileFormat = ".csv";
   }
   
    $PreAssessmentOutputPath ="$path\Results\Performance"
    $fileExt = "*"+$FileFormat
    $csvs=(ls $PreAssessmentOutputPath -Filter $fileExt).count
             
    if($csvs -gt 0) 
    { 
        $TempMess = "Found existing Output folder with $csvs files"
        Write-Host $TempMess -ForegroundColor Yellow 
        Write-Host "Do you want to overwrite the existing files or append new data to the existing files ?"-ForegroundColor Yellow 

        $response = Read-Host "[A] Append [O] Overwrite (default is `"A`")" 
        if($response -eq "O")
        {
            try{
                Remove-Item –path (join-path $PreAssessmentOutputPath "\*") -ErrorAction Stop
                $TempMess = "$PreAssessmentOutputPath folder cleared"
                Write-Host "■ [SUCCESS] " -ForegroundColor Green -NoNewline
                Write-Host $TempMess 
                
            }
            catch
            {
                $TempMess = "  $PreAssessmentOutputPath folder cleanup Failed with error.... $($_.Exception.Message)"
                Write-Host "      ■ [ERROR] " -ForegroundColor Red -NoNewline
                Write-Host $TempMess  
                return
            }
        }
        elseif($response -eq "A" -or !$response)
        {
            $TempMess = "Appending to Output folder"
            Write-Host "■ [SUCCESS] " -ForegroundColor Green -NoNewline
            Write-Host $TempMess 
        }
        else
        {
            $TempMess = "Wrong choice"
            Write-Host "■ [WARNING] " -ForegroundColor Yellow -NoNewline
            Write-Host $TempMess 
            return
        }
    }

    #Instances List
    if ($PreAssessmentServerFile -contains ":") {
			#Absolute path entered
	}
	else {
		$PreAssessmentServerFile = "$path\Scripts\InstanceList_DMA_Performance.csv"
        $SQLPerformanceQueriesFile="$path\Scripts\SQLSynapsePerfStats\SQLScriptsToRun.csv"
	}
    
    $IntancecsvFile     = Import-Csv $PreAssessmentServerFile | ? Active -eq "1"    
    $Queries            = Import-Csv $SQLPerformanceQueriesFile | ? Active -eq "1"    
    $PerformanceQueries = $Queries | where DataCollection -eq "Perf"     
    $SnapshotQueries    = $Queries | where DataCollection -eq "Snapshot"
 
     $ScriptPath=$path
    $FolderPath = $ScriptPath
     
    foreach($InstanceScriptToRun in $IntancecsvFile)
    {
            $Environment =$InstanceScriptToRun.Environment    
            $InstanceName=$InstanceScriptToRun.InstanceName

               try
               {
        
                    $DBlist="";

                    if($InstanceScriptToRun.Port -gt "0")
                    {
                        $Port        =$InstanceScriptToRun.Port
                        $InstanceName=$InstanceScriptToRun.InstanceName+","+$Port
                    } 

                    $AuthType    =$InstanceScriptToRun.AuthType
                    $UserName    =$InstanceScriptToRun.UserName
                    $Password    =$InstanceScriptToRun.Password 
                    $ConnectionType=$AuthType                    
                    $ConnectionTimeout= $InstanceScriptToRun.ConnectionTimeout
                    $QueryTimeout= $InstanceScriptToRun.QueryTimeout 
                     
                  Write-Host "Data collection Started for Instance : $InstanceName" -ForegroundColor Yellow
    
                  $timer = new-timespan -Minutes $PerCollectionTime_In_Min
                  $clock = [diagnostics.stopwatch]::StartNew()

                  while ($clock.elapsed -lt $timer)
                  { 
                    foreach($QueriesFile in $PerformanceQueries)
                    {
           
                        $ScriptName     = $QueriesFile.ScriptName
                        $ExportFileName = $QueriesFile.ExportFileName
                        $DataCollection = $QueriesFile.DataCollection

                        $QueriesFilePath = $ScriptPath+"\Scripts"+$ScriptName
  
                        $SQLStatement = Get-Content -Path $QueriesFilePath -Raw
                        
                        if ($DataCollection -eq "Perf")
                        {
                             
                            if(($Environment -contains "SQLServer") -or ($Environment -contains "AzureManagedSQLDB"))
                            {
                                if($Environment -eq "SQLServer")
                                {
                                    
                                    if($UserName -eq "" -and $Password -eq "")
                                    {
                                        $ConnectionString = "Data Source=$InstanceName;Initial Catalog=master;Integrated Security=true;Connection Timeout=$ConnectionTimeout $stringparam";
                                    }
                                    else
                                    {
                                        $ConnectionString = "Data Source=$InstanceName;Initial Catalog=master;User Id=$UserName;Password=$Password;Connection Timeout=$ConnectionTimeout $stringparam";
                                    }
                                }
                                else
                                {
                                    $ConnectionString = "Server=tcp:$InstanceName;Initial Catalog=master;Persist Security Info=False;User ID=$UserName;Password=$Password;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=$ConnectionTimeout ";
                                }

                                try 
                                {    
                                    $dataset =GetSQLDataSet $ConnectionString $SQLStatement  
                                    $ToExport=$dataset[1]
                                    $FileName= $ScriptPath+"\Results\Performance\"+$ExportFileName+$FileFormat
                                    $ToExport | Export-Csv -Path $FileName -NoTypeInformation -Append -Delimiter ","  -Encoding UTF8
                                }
                                catch 
                                {
                                    $MyError = $($_.Exception.Message).replace("Exception calling ""Open"" with ""0"" argument(s): ", "")
                                }
 

                            }        
                            else  #for Azure SQL Database
                            {        
                                $DMADbName=$InstanceScriptToRun.DatabaseName
                                if(($DMADbName -contains "master") -or ($DMADbName -contains "%"))
                                {
                                    if($UserName -eq "" -and $Password -eq "")
                                    {
                                        Write-Host "Please enter username and password in instance file"
                                        return
                                    }
                                    else
                                    {
                                        $String = "Server=tcp:$InstanceName;Initial Catalog=master;Persist Security Info=False;User ID=$UserName;Password=$Password;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=$ConnectionTimeout $stringparam";
                                    }
                                   $SQLquery  ="select name from sys.databases where name not in ('master','msdb','tempdb','model')"
                                   $DBdataset =GetSQLDataSet $String $SQLquery  
                                   $DMADbNameList=$DBdataset[1]  
                                }
                                else
                                {
                                    $DMADbNameList = $DMADbName.split(',');
                                }
            
                                # this works only for azure SQL Dabase and Synapse            
                                foreach($dbname in $DMADbNameList)
                                {
                                 
                                     if(($DMADbName -contains "master") -or ($DMADbName -contains "%"))
                                     { 
                                        $db = $dbname.name
                                     }
                                     else
                                     {
                                        $db=$dbname
                                     }
                             
                                
                                    if($db -ne "")
                                    {
                                        if($UserName -eq "" -and $Password -eq "")
                                        {
                                            Write-Host "Please enter username and password in instance file"
                                            return
                                        }
                                        else
                                        {
                                            $ServersqlConnectionString = "Server=tcp:$InstanceName,1433;Initial Catalog=$db;Persist Security Info=False;User ID=$UserName;Password=$Password;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=$ConnectionTimeout;";
                                        }
                   
                  
                                        try 
                                        {  
                                            $dataset =GetSQLDataSet $ServersqlConnectionString $SQLStatement  
                                            $ToExport=$dataset[1]
                                            $FileName= $ScriptPath+"\Results\Performance\"+$ExportFileName+$FileFormat
                                            $ToExport | Export-Csv -Path $FileName -NoTypeInformation -Append -Delimiter "," # -Encoding UTF8
                                        }
                                        catch 
                                        {
                                            $MyError = $($_.Exception.Message).replace("Exception calling ""Open"" with ""0"" argument(s): ", "")
                                        } 
                                    }
                                    
                                 }
                             }
                           } 
                        }
                    
                    if ([Console]::KeyAvailable)
                    {
                        $keyInfo = [Console]::ReadKey($true)
                        # exit loop
                        break
                    }
                
                    Start-Sleep -Seconds $samplingPeriod_In_Sec 
                    #Write-Progress -Activity "Search in Progress" -Status "$samplingPeriod_In_Sec% Complete:" -PercentComplete $samplingPeriod_In_Sec                                
                  }    
                  
                   #Running Snapshots  
                   $QueriesFile ="";
                    Write-Host "Running Snapshots queries..."
                    foreach($QueriesFile in $SnapshotQueries)
                    {
           
                        $ScriptName     = $QueriesFile.ScriptName
                        $ExportFileName = $QueriesFile.ExportFileName
                        $DataCollection = $QueriesFile.DataCollection
                        $Runfor         = $QueriesFile.Runfor

                        $QueriesFilePath = $ScriptPath+"\Scripts"+$ScriptName
  
                        $SQLStatement = Get-Content -Path $QueriesFilePath -Raw
                        
                        if ($DataCollection -eq "Snapshot")
                        {
                             
                            
                            #if(($Environment -contains "SQLServer") -or ($Environment -contains "AzureManagedSQLDB"))
                            #{
                            if($Runfor -eq "Server")
                            {
                                    if($Environment -eq "SQLServer")
                                    {
                                    
                                        if($UserName -eq "" -and $Password -eq "")
                                        {
                                            $ConnectionString = "Data Source=$InstanceName;Initial Catalog=master;Integrated Security=true;Connection Timeout=$ConnectionTimeout $stringparam";
                                        }
                                        else
                                        {
                                            $ConnectionString = "Data Source=$InstanceName;Initial Catalog=master;User Id=$UserName;Password=$Password;Connection Timeout=$ConnectionTimeout $stringparam";
                                        }
                                    }
                                    else
                                    {
                                        $ConnectionString = "Server=tcp:$InstanceName;Initial Catalog=master;Persist Security Info=False;User ID=$UserName;Password=$Password;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=$ConnectionTimeout ";
                                    }

                                    try 
                                    {    
                                       
                                        Write-Host "Running Query - " $ExportFileName
                                  
                                        $dataset =GetSQLDataSet $ConnectionString $SQLStatement  
                                        $ToExport=$dataset[1]
                                        $FileName= $ScriptPath+"\Results\Performance\"+$ExportFileName+$FileFormat
                                        $ToExport |Export-Csv -Path $FileName -NoTypeInformation -Append -Delimiter ","  -Encoding UTF8
                                    }
                                    catch 
                                    {
                                        $MyError = $($_.Exception.Message).replace("Exception calling ""Open"" with ""0"" argument(s): ", "")
                                    }
                            }        
                            else  #for all sql env
                            {        
                                $DMADbName=$InstanceScriptToRun.DatabaseName
                                if(($DMADbName -contains "master") -or ($DMADbName -contains "%"))
                                {
                                    
                                    if($Environment -eq "SQLServer")
                                    {
                                    
                                        if($UserName -eq "" -and $Password -eq "")
                                        {
                                            $ConnectionString = "Data Source=$InstanceName;Initial Catalog=master;Integrated Security=true;Connection Timeout=$ConnectionTimeout $stringparam";
                                        }
                                        else
                                        {
                                            $ConnectionString = "Data Source=$InstanceName;Initial Catalog=master;User Id=$UserName;Password=$Password;Connection Timeout=$ConnectionTimeout $stringparam";
                                        }
                                    }
                                    else
                                    {
                                        $ConnectionString = "Server=tcp:$InstanceName;Initial Catalog=master;Persist Security Info=False;User ID=$UserName;Password=$Password;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=$ConnectionTimeout ";
                                    }
                                   
                                   $SQLquery  ="select name from sys.databases where name not in ('master','msdb','tempdb','model','distribution')"
                               
                                   $DBdataset =GetSQLDataSet $ConnectionString $SQLquery  
                                   $DMADbNameList=$DBdataset[1]                                   

                                }
                                else
                                {
                                    $DMADbNameList = $DMADbName.split(',');
                                }
            
                                # this works only for azure SQL Dabase and Synapse            
                                foreach($dbname in $DMADbNameList)
                                {
                                    if(($DMADbName -contains "master") -or ($DMADbName -contains "%"))
                                    { 
                                        $db = $dbname.name
                                     }
                                     else
                                     {
                                        $db=$dbname
                                     }
                                    if($db -ne "")
                                    {
                                        if($Environment -eq "SQLServer")
                                        {
                                    
                                            if($UserName -eq "" -and $Password -eq "")
                                            {
                                                $ConnectionString = "Data Source=$InstanceName;Initial Catalog=$db;Integrated Security=true;Connection Timeout=$ConnectionTimeout $stringparam";
                                            }
                                            else
                                            {
                                                $ConnectionString = "Data Source=$InstanceName;Initial Catalog=$db;User Id=$UserName;Password=$Password;Connection Timeout=$ConnectionTimeout $stringparam";
                                            }
                                        }
                                        else
                                        {
                                            $ConnectionString = "Server=tcp:$InstanceName;Initial Catalog=$db;Persist Security Info=False;User ID=$UserName;Password=$Password;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=$ConnectionTimeout ";
                                        }
                                     
                  
                                        try 
                                        {  
                                            Write-Host "Running Query $ExportFileName against database - " $db
                                            $dataset =GetSQLDataSet $ConnectionString $SQLStatement  
                                            $ToExport=$dataset[1]
                                            $FileName= $ScriptPath+"\Results\Performance\"+$ExportFileName+$FileFormat
                                            $ToExport | Export-Csv -Path $FileName -NoTypeInformation -Append -Delimiter ","  -Encoding UTF8
                                        }
                                        catch 
                                        {
                                            $MyError = $($_.Exception.Message).replace("Exception calling ""Open"" with ""0"" argument(s): ", "")
                                        } 
                                    }
                                    
                                 }

                             }
                        } 
                    }                                         
                   Write-Host "Data Collection Completed Successfully and data has been saved into $ScriptPath\Results\Performance folder."
               }
               catch
               {
                   $TempMess = " Perf collection - Failed with errors.... $($_.Exception.Message)"
                   Write-Host "      ■ [ERROR] " -ForegroundColor Red -NoNewline
                   Write-Host $TempMess  
               }
        }
 
      #Write-Host "All captured data will be saved at $ScriptPath\Results\Performance"
}
  